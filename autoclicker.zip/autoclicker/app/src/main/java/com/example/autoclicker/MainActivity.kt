package com.example.autoclicker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "Auto Clicker"
            textSize = 28f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }

        val steps = TextView(this).apply {
            text = """
                الخطوات:

                1) اضغط الزر أدناه ثم افتح «التطبيقات المثبّتة» وفعّل Auto Clicker.
                2) ستظهر على الشاشة لوحة تحكم ودائرة حمراء.
                3) اسحب الدائرة إلى المكان الذي تريد النقر عليه.
                4) اضبط السرعة بأزرار + و −، ثم اضغط ▶ للتشغيل و ■ للإيقاف.

                ملاحظة: لا يحتاج التطبيق إلى أي إذن غير خدمة إمكانية الوصول، ولا يجمع أي بيانات.
            """.trimIndent()
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, pad, 0, pad)
        }

        val open = Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        root.addView(title)
        root.addView(steps)
        root.addView(open)
        setContentView(root)
    }
}
