package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView

/**
 * خدمة إمكانية وصول تعرض طبقتين فوق كل التطبيقات:
 *  - لوحة تحكم (تشغيل/إيقاف، السرعة، عدّاد النقرات)
 *  - دائرة هدف تُسحب إلى مكان النقر
 * وتنفّذ نقرة عبر dispatchGesture كل [intervalMs] ملّي ثانية أثناء التشغيل.
 */
class ClickerService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var panel: View? = null
    private var target: View? = null
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var targetParams: WindowManager.LayoutParams

    private lateinit var toggleBtn: TextView
    private lateinit var intervalTxt: TextView
    private lateinit var countTxt: TextView

    private var running = false
    private var intervalMs = 200L
    private var taps = 0

    private val tapLoop = object : Runnable {
        override fun run() {
            if (!running) return
            performTap()
            handler.postDelayed(this, intervalMs)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (panel == null) {
            buildTarget()
            buildPanel()
        }
    }

    // ---------------------------------------------------------------- الهدف

    private fun buildTarget() {
        val size = dp(56)
        val view = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(110, 255, 59, 48))
                setStroke(dp(3), Color.argb(230, 255, 59, 48))
            }
        }
        targetParams = overlayParams(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels / 2 - size / 2
            y = resources.displayMetrics.heightPixels / 2 - size / 2
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = targetParams.x; startY = targetParams.y
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    targetParams.x = startX + (e.rawX - touchX).toInt()
                    targetParams.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(view, targetParams)
                }
            }
            true
        }
        wm.addView(view, targetParams)
        target = view
    }

    /** أثناء التشغيل تمرّ اللمسات من خلال الدائرة، وعند الإيقاف تصبح قابلة للسحب. */
    private fun setTargetTouchable(touchable: Boolean) {
        val v = target ?: return
        targetParams.flags = if (touchable) {
            targetParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            targetParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        wm.updateViewLayout(v, targetParams)
    }

    // ------------------------------------------------------------ لوحة التحكم

    private fun button(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 20f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        minWidth = dp(44)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        setOnClickListener { onClick() }
    }

    private fun buildPanel() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.argb(225, 30, 30, 34))
            }
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        val handle = button("⠿") {}
        toggleBtn = button("▶") { toggle() }
        val minus = button("−") { changeInterval(-50) }
        intervalTxt = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            minWidth = dp(58)
        }
        val plus = button("+") { changeInterval(+50) }
        countTxt = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 14f
            gravity = Gravity.CENTER
            minWidth = dp(40)
        }
        val close = button("✕") { stopSelf(); disableSelf() }

        listOf(handle, toggleBtn, minus, intervalTxt, plus, countTxt, close).forEach(row::addView)
        refreshLabels()

        panelParams = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(120)
        }

        // السحب من المقبض فقط (⠿)
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = panelParams.x; startY = panelParams.y
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    panelParams.x = startX + (e.rawX - touchX).toInt()
                    panelParams.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(row, panelParams)
                }
            }
            true
        }

        wm.addView(row, panelParams)
        panel = row
    }

    private fun refreshLabels() {
        toggleBtn.text = if (running) "■" else "▶"
        intervalTxt.text = "${intervalMs}ms"
        countTxt.text = taps.toString()
    }

    private fun changeInterval(delta: Long) {
        intervalMs = (intervalMs + delta).coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS)
        refreshLabels()
    }

    // --------------------------------------------------------------- النقر

    private fun toggle() {
        if (running) stopClicking() else startClicking()
    }

    private fun startClicking() {
        running = true
        taps = 0
        setTargetTouchable(false)
        refreshLabels()
        handler.post(tapLoop)
    }

    private fun stopClicking() {
        running = false
        handler.removeCallbacks(tapLoop)
        setTargetTouchable(true)
        refreshLabels()
    }

    private fun performTap() {
        val v = target ?: return
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        val x = loc[0] + v.width / 2f
        val y = loc[1] + v.height / 2f

        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, TAP_DURATION_MS))
            .build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                taps++
                countTxt.text = taps.toString()
            }
        }, null)
    }

    // ---------------------------------------------------------------- عام

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        stopClicking()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        removeOverlays()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        removeOverlays()
        super.onDestroy()
    }

    private fun removeOverlays() {
        running = false
        handler.removeCallbacks(tapLoop)
        panel?.let { runCatching { wm.removeView(it) } }
        target?.let { runCatching { wm.removeView(it) } }
        panel = null
        target = null
    }

    companion object {
        private const val MIN_INTERVAL_MS = 50L
        private const val MAX_INTERVAL_MS = 10_000L
        private const val TAP_DURATION_MS = 30L
    }
}
